class add{
    static void addit(int a,int b)
    {
        System.out.println("Sum="+(a+b));
    }
}
class object {
    public static void main(String[] args) {
        int a=5,b=10;
        add.addit(a, b);

    }
    
}
