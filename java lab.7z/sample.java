class sample {
    public static void main(String args[])
    {
    String s="I am Fine";
    System.out.println(s.indexOf("m"));
    }
    }