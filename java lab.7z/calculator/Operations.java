package calculator;
public class Operations
{
    public static void addition(int a,int b)
    {
        System.out.println("Sum="+(a+b));
    }
    public void multiplication(int a,int b)
    {
        System.out.println("Value="+(a*b));

    }
    public static void substraction(int a,int b)
    {
        if(a>b)
        {
            System.out.println("Value="+(a-b));
        }
        else
        {
            System.out.println("Value="+(b-a));
        }

    }
    public static void division(int a,int b)
    {
        System.out.println("Value="+(a/b));
    }
}