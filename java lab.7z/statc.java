class a
{
    static int a=10;
    static int b=20;
}
class statc
{
    public static void main(String args[])
    {
        System.out.println((a.b+a.a));
    }
}