package MyCalculator;
import calculator.*;
import java.util.*;
public class MYCalculator {
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter numbers");
        int a=sc.nextInt();
        int b=sc.nextInt();
        Operations obj=new Operations();
        obj.multiplication(a,b);
        sc.close();
    }
    
}
